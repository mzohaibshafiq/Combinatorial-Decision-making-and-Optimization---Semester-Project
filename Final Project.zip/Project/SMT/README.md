# files 
src folder contains VLSI-OPT.ipynb notebook which can be exceuted on jupyter notebook having z3 library installed. 
Instance folder contains all the instances provided for the task, and for successful execution this folder should 
be in the same directory as python notebook, otherwise path should be provided in code.  
Output folder contains the output fles of same instances. 
In order to execute the output code this folder should also be in the same directory or path should be provided. 

